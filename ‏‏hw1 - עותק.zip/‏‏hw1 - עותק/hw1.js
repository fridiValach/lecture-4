const express = require("express");
const app = express();
const htmlTags = require(`../../node js/hw1/htmlTags`);
console.log("htmlTags",htmlTags);
 
htmlTags.forEach((el) => {
    console.log(htmlTags.el)
    let tag=[el]
      app.get("/" + el.name, (req, res) => {
        res.send(el.tag);
      });
    });
    
app.listen(5001);
