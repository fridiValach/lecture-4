const tags=[
    {name:"support",
    tag:`<div>support</div>`},
    {name:"helloHeb",
    tag:`<div>שלום!</div>`},
    {name:"helloEng",
    tag:`<div>hello</div>`},
    {name:"goodBye",
    tag:`<div>good bye!</div>`},
    {name:"",
    tag:`<div>error - empty</div>`}
  ]
module.exports=tags

